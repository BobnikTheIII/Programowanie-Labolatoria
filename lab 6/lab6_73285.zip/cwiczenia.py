import f_mat as f_mat

f_mat.kwadrat(10)
f_mat.szescian(3)
f_mat.dodaj(10,5)