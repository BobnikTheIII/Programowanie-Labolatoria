import temperatura as temp

print(temp.c_to_f(20))
print(temp.f_to_c(86))
print(temp.c_to_k(20))