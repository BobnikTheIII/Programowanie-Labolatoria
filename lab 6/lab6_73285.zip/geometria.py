pi = 3.14159

def obwod_kola(promien):
    return promien*2*pi


def pole_kola(promien):
    return promien*promien*pi

