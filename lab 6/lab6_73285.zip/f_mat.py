def kwadrat(x):
    return x*x

def szescian(x):
    return x*x*x

def dodaj(a,b):
    return a+b